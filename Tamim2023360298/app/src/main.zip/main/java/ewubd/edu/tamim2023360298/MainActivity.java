package ewubd.edu.tamim2023360298;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    private Button btnExit,btnAddNew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnExit = findViewById(R.id.btnExit);
        btnAddNew = findViewById(R.id.btnAddNew);


        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("btnExit...mainActivity");
                finish();
            }
        });


        btnAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("btnAddNew...mainActivity");
                Intent i = new Intent(MainActivity.this, BirthdayInfoActivity.class);
                startActivity(i);
            }
        });

    }


    public void onStart(){
        super.onStart();
        System.out.println("onStart...mainActivity");
    }

    public void onPause(){
        super.onPause();
        System.out.println("onPause...mainActivity");
    }

    public void onResume(){
        super.onResume();
        System.out.println("onResume....mainActivity");
    }

    public void onStop(){
        super.onStop();
        System.out.println("onStop...mainActivity");
    }

    public void onDestroy(){
        super.onDestroy();
        System.out.println("onDestroy...mainActivity");
    }
}